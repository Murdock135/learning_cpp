#include <iostream>

class lineType{
    private:
        double a, b, c;
        static int lineCount;

    public:
        lineType(double x_coef, double y_coef, double y_intercept);
        double getslope();
        static int getlineCount();
};

lineType::lineType(double x_coef, double y_coef, double y_intercept){
    this-> a = x_coef;
    this-> b = y_coef;
    this-> c = y_intercept;
    lineType::lineCount++;
}

double lineType::getslope(){
    double slope = -a/b;

    return slope;
}

int lineType::getlineCount(){
    return lineCount;
}



int main(){
    lineType line1(1,2,0);
    lineType line2(2,4,0);

    double slope1 = line1.getslope();
    
    std::cout << "Slope of line1: " << slope1 << '\n';

    return 0;
}